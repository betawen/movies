from login import app
from flask import redirect,request,render_template
from models import Film
from database import db
# from spider2 import ListSpider
# spider=ListSpider()
 
# list= spider.get_all_movie_infos(2)

# def add_films():
#     for f in list:
#         film=Film(f)
#         db.session.add(film)
#         db.session.commit()

# @app.route('/')
# def films():
#     add_films()
#     return render_template('index.html')

# # @app.route('/choose',methods=['POST'])
# # def choose():
# #     film=request.form.get('filmname')

# if __name__=='__main__':
#     app.run()


